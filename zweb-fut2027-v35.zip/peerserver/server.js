// FUT 27 · servidor del online.
//  · PeerJS (ruta /): ayuda a que dos jugadores se conecten para el partido; los datos del partido van directos entre ellos.
//  · /api: quién está en línea e invitaciones entre amigos, por HTTP (funciona con cualquier red, sin conexión directa).
const express = require('express');
const http = require('http');
const { ExpressPeerServer } = require('peer');
const { WebSocketServer } = require('ws');
const app = express();
const server = http.createServer(app);
const ID = /^[a-z0-9_]{3,14}-\d{4}$/;
const LABEL = /^[A-Za-z0-9_]{3,14}#\d{4}$/;
const CODE = /^[A-Z0-9]{4}$/;
const seen = new Map();  // id -> { t, v }
const inbox = new Map(); // id -> [mensajes]
const ONLINE_MS = 12000;
function online(id) { const s = seen.get(id); return s && Date.now() - s.t < ONLINE_MS ? s : null; }
function push(id, m) { let q = inbox.get(id); if (!q) { q = []; inbox.set(id, q); } q.push(m); if (q.length > 20) q.shift(); }
function s(v, n) { return String(v == null ? '' : v).slice(0, n); }
app.use((req, res, next) => { res.set('Access-Control-Allow-Origin', '*'); if (req.path.startsWith('/api/')) res.set('Cache-Control', 'no-store'); next(); });
app.get('/health', (req, res) => res.send('ok'));
// cada cliente avisa cada pocos segundos que sigue abierto y recoge sus mensajes
app.get('/api/hello', (req, res) => {
  const id = s(req.query.u, 20).toLowerCase();
  if (!ID.test(id)) return res.status(400).json({ e: 'id' });
  seen.set(id, { t: Date.now(), v: s(req.query.v, 12) });
  const now = Date.now(), q = (inbox.get(id) || []).filter(m => now - m.t < 60000);
  inbox.delete(id);
  res.json({ ok: 1, msgs: q });
});
// ¿quién de esta lista está en línea?
app.get('/api/online', (req, res) => {
  const out = {};
  s(req.query.u, 1500).toLowerCase().split(',').filter(x => ID.test(x)).slice(0, 60).forEach(id => { const o = online(id); out[id] = o ? { v: o.v } : 0; });
  res.json(out);
});
// mensajes entre amigos: invitación (inv), rechazo (no) o invitación retirada (cancel)
app.get('/api/send', (req, res) => {
  const to = s(req.query.to, 20).toLowerCase(), from = s(req.query.from, 20), k = s(req.query.k, 8);
  if (!ID.test(to) || !LABEL.test(from) || ['inv', 'no', 'cancel'].indexOf(k) < 0) return res.status(400).json({ e: 'args' });
  const m = { k, from, t: Date.now() };
  if (k === 'inv') { m.code = s(req.query.code, 4).toUpperCase(); m.rg = s(req.query.rg, 8).replace(/[^a-z]/g, ''); m.v = s(req.query.v, 12); if (!CODE.test(m.code)) return res.status(400).json({ e: 'code' }); }
  if (!online(to)) return res.json({ ok: 0, e: 'offline' });
  push(to, m);
  res.json({ ok: 1, v: online(to).v });
});
setInterval(() => {
  const now = Date.now();
  for (const [id, o] of seen) if (now - o.t > 120000) seen.delete(id);
  for (const [id, q] of inbox) if (!q.length || now - q[q.length - 1].t > 120000) inbox.delete(id);
}, 30000);
// --- plan B del partido: si la conexión directa entre los dos no abre, los mensajes pasan por aquí (sala = anfitrión + invitado)
const rooms = new Map(); // sala -> { host: ws, guests: Map(id -> ws) }
const relay = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });
function rid() { return 'r' + Math.random().toString(36).slice(2, 10); }
function out(ws, o) { try { if (ws.readyState === 1) ws.send(JSON.stringify(o)); } catch (e) { /* cerrada */ } }
relay.on('connection', (ws, req) => {
  const q = new URL(req.url, 'http://x').searchParams;
  const room = s(q.get('room'), 60).toLowerCase(), role = q.get('role') === 'host' ? 'host' : 'guest';
  if (!/^[a-z0-9-]{6,60}$/.test(room)) { out(ws, { sys: 'bad' }); return ws.close(); }
  ws.id = rid(); ws.room = room; ws.role = role; ws.alive = true;
  ws.on('pong', () => { ws.alive = true; });
  let r = rooms.get(room);
  if (role === 'host') {
    if (r && r.host && r.host.readyState === 1) { out(ws, { sys: 'taken' }); return ws.close(); }
    r = { host: ws, guests: r ? r.guests : new Map() }; rooms.set(room, r);
    out(ws, { sys: 'ok', id: ws.id });
    for (const [gid] of r.guests) out(ws, { sys: 'join', id: gid });
  } else {
    if (!r || !r.host || r.host.readyState !== 1) { out(ws, { sys: 'nohost' }); return ws.close(); }
    r.guests.set(ws.id, ws);
    out(ws, { sys: 'ok', id: ws.id }); out(ws, { sys: 'join', id: r.host.id }); out(r.host, { sys: 'join', id: ws.id });
  }
  ws.on('message', (raw) => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    const rr = rooms.get(room); if (!rr) return;
    const to = rr.host && rr.host.id === m.t ? rr.host : rr.guests.get(m.t);
    if (to && to !== ws) out(to, { f: ws.id, d: m.d });
  });
  ws.on('close', () => {
    const rr = rooms.get(room); if (!rr) return;
    if (rr.host === ws) { for (const [, g] of rr.guests) { out(g, { sys: 'leave', id: ws.id }); g.close(); } rooms.delete(room); }
    else if (rr.guests.delete(ws.id) && rr.host) out(rr.host, { sys: 'leave', id: ws.id });
  });
});
setInterval(() => { relay.clients.forEach(ws => { if (!ws.alive) return ws.terminate(); ws.alive = false; try { ws.ping(); } catch (e) { /* nada */ } }); }, 25000);
// PeerJS con su propio servidor de WebSocket; las conexiones se reparten a mano por ruta
let peerWss = null;
app.use('/', ExpressPeerServer(server, { path: '/', proxied: true, allow_discovery: false, corsOptions: { origin: true }, alive_timeout: 60000,
  createWebSocketServer: (o) => (peerWss = new WebSocketServer({ noServer: true, path: o.path })) }));
server.on('upgrade', (req, socket, head) => {
  const path = new URL(req.url, 'http://x').pathname;
  if (path === '/relay') relay.handleUpgrade(req, socket, head, (ws) => relay.emit('connection', ws, req));
  else if (peerWss && peerWss.shouldHandle(req)) peerWss.handleUpgrade(req, socket, head, (ws) => peerWss.emit('connection', ws, req));
  else socket.destroy();
});
const port = process.env.PORT || 9000;
server.listen(port, '0.0.0.0', () => console.log('Servidor FUT 27 en el puerto ' + port));
