// FUT 27 · servidor de señalización PeerJS propio (solo ayuda a que dos jugadores se encuentren; los datos van directos entre ellos)
const express = require('express');
const http = require('http');
const { ExpressPeerServer } = require('peer');
const app = express();
const server = http.createServer(app);
app.get('/health', (req, res) => res.send('ok'));
app.use('/', ExpressPeerServer(server, { path: '/', proxied: true, allow_discovery: false, corsOptions: { origin: true }, alive_timeout: 60000 }));
const port = process.env.PORT || 9000;
server.listen(port, '0.0.0.0', () => console.log('PeerServer FUT 27 en el puerto ' + port));
